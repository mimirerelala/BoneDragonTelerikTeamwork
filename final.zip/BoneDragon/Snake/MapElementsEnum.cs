﻿namespace Snake
{
    public enum MapElementsEnum
    {
        None = 0,
        Rock = 1,
        Fruit = 2,
        Snake = 3
    }
}
