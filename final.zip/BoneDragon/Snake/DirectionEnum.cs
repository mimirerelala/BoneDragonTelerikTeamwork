﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    public enum DirectionEnum
    {
        right = 0,
        left = 1,
        down = 2,
        up = 3
    }
}
